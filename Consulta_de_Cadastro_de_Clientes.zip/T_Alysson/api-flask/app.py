from flask import Flask, request
from flask_cors import CORS
from collections import OrderedDict # parecido c/ o dicionario dict, mas mantém em ordem
import json
import os  # operational system

# pip install flask-cors
app = Flask("Minha API")
CORS(app)  # Ativa cors

@app.route("/")
def homepage():
    return "Hello World!"

# Tentativa final de deixar o conteúdo json em ordem alfabética
# No ínicio foi sem mas o resultado apresentado teve auxilio do chatgpt
@app.route("/consulta", methods=["GET"])
def consulta_cadastro():
    documento = request.args.get("doc")
    if documento:
        registro = dados(documento)
        return registro
    else:
        todos_os_dados = carregar_arquivo()
        dados_ordenados = sorted(todos_os_dados.items(), key=lambda x: x[1]['nome'])
        dados_ordenados_dict = OrderedDict((cpf, dados) for cpf, dados in dados_ordenados)
        return json.dumps(dados_ordenados_dict, indent=4)

@app.route("/cadastro", methods=["POST"])
def cadastrar():
    payload = request.json
    cpf = payload.get("cpf")
    valores = payload.get("dados")
    salvar_dados(cpf, valores)
    return "dados cadastrados"
           
def carregar_arquivo():
    # caminho de onde o arquivo está salvo
    caminho_arquivo = os.path.realpath("api-flask/dados.json")
    try:
        with open(caminho_arquivo, "r") as arq:
            return json.load(arq)
    except Exception as e:
        return {"error": f"Falha ao carregar o arquivo: {str(e)}"}

def gravar_arquivo(dados):
    caminho_arquivo = os.path.realpath("api-flask/dados.json")
    try:
        with open(caminho_arquivo, "w") as arq:
            json.dump(dados, arq, indent=4)
        return "dados armazenados"
    except Exception:
        return "Falha ao carregar o arquivo"

def salvar_dados(cpf, registro):
    dados_pessoas = carregar_arquivo()
    dados_pessoas[cpf] = registro
    gravar_arquivo(dados_pessoas)

def dados(cpf):
    dados_pessoas = carregar_arquivo()
    vazio = {
        "nome": "Nao encontrado",
        "data_nascimento": "Nao encontrado",
        "email": "Nao encontrado",
    }
    cliente = dados_pessoas.get(cpf, vazio)
    return cliente

if __name__ == "__main__":
    app.run(debug=True)
    

   